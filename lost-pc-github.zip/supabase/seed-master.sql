-- 最初のマスターデータ例。必要な店舗名へ編集してから実行してください。
insert into public.master_records(master_type,code,name,sort_order,metadata) values
('store','NMB','大阪なんば本店',10,'{"area":"大阪"}'),
('store','UMD','大阪梅田店',20,'{"area":"大阪"}'),
('store','KSM','神戸三宮店',30,'{"area":"兵庫"}')
on conflict do nothing;

insert into public.master_records(master_type,name,sort_order,metadata) values
('category','財布・現金',10,'{"emoji":"👛"}'),('category','カード類',20,'{"emoji":"▤"}'),('category','鍵',30,'{"emoji":"🔑"}'),('category','スマートフォン',40,'{"emoji":"▯"}'),('category','衣類',50,'{"emoji":"👕"}'),('category','靴',60,'{"emoji":"👟"}'),('category','タオル',70,'{"emoji":"▱"}'),('category','傘',80,'{"emoji":"☂"}'),('category','水筒・ボトル',90,'{"emoji":"◉"}'),('category','バッグ',100,'{"emoji":"▣"}'),('category','アクセサリー',110,'{"emoji":"◇"}'),('category','眼鏡',120,'{"emoji":"◌"}'),('category','その他',999,'{"emoji":"□"}'),
('found_location','受付',10,'{}'),('found_location','更衣室',20,'{}'),('found_location','トレーニングエリア',30,'{}'),('found_location','トイレ',40,'{}'),('found_location','入口',50,'{}'),
('storage_location','貴重品金庫',10,'{}'),('storage_location','受付保管棚',20,'{}'),('storage_location','保管ボックス',30,'{}')
on conflict do nothing;
