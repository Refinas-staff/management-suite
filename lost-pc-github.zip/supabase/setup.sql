-- 同じSupabaseプロジェクト内で3画面を安全に動かすための初期設定
-- Supabase Dashboard > SQL Editor で実行してください。

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'customer_success' check (role in ('admin','lost_manager','lost_register','insurance_manager','customer_success')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.master_records (
  id uuid primary key default gen_random_uuid(),
  master_type text not null check (master_type in ('store','category','found_location','storage_location')),
  code text,
  name text not null,
  parent_id uuid references public.master_records(id) on delete restrict,
  sort_order integer not null default 10,
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists master_records_type_order_idx on public.master_records(master_type,is_active,sort_order);
create unique index if not exists master_records_unique_name_parent_idx on public.master_records(master_type,lower(name),coalesce(parent_id,'00000000-0000-0000-0000-000000000000'::uuid));
create unique index if not exists master_records_store_code_idx on public.master_records(code) where master_type='store' and code is not null;

create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.lost_items (
  id uuid primary key default gen_random_uuid(),
  management_no text unique,
  store_id uuid not null references public.master_records(id),
  category_id uuid not null references public.master_records(id),
  found_location_id uuid not null references public.master_records(id),
  storage_location_id uuid not null references public.master_records(id),
  found_at timestamptz not null,
  expiry_date date,
  item_name text not null,
  color text,
  features text,
  notes text,
  status text not null default '保管中' check (status in ('保管中','問い合わせあり','返却済み','廃棄済み')),
  photo_path text,
  created_by uuid references auth.users(id),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists lost_items_store_status_idx on public.lost_items(store_id,status,found_at desc);
create index if not exists lost_items_management_no_idx on public.lost_items(management_no);

create table if not exists public.insurance_claims (
  id uuid primary key default gen_random_uuid(),
  member_name text not null,
  store_id uuid not null references public.master_records(id),
  injury_date date not null,
  application_status text not null default '未確認' check (application_status in ('未確認','会員へ確認中','必要書類待ち','申請準備中','保険会社へ申請済み','保険会社確認中','追加対応待ち','支払い手続き中','支払い完了','対象外','保留')),
  next_action text,
  next_action_date date,
  notes text,
  created_by uuid references auth.users(id),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists insurance_claims_member_idx on public.insurance_claims(member_name);
create index if not exists insurance_claims_status_date_idx on public.insurance_claims(application_status,next_action_date);

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end $$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
drop trigger if exists masters_updated_at on public.master_records;
create trigger masters_updated_at before update on public.master_records for each row execute function public.set_updated_at();
drop trigger if exists settings_updated_at on public.app_settings;
create trigger settings_updated_at before update on public.app_settings for each row execute function public.set_updated_at();
drop trigger if exists lost_items_updated_at on public.lost_items;
create trigger lost_items_updated_at before update on public.lost_items for each row execute function public.set_updated_at();
drop trigger if exists insurance_updated_at on public.insurance_claims;
create trigger insurance_updated_at before update on public.insurance_claims for each row execute function public.set_updated_at();

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,role) values(new.id,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1)),'customer_success') on conflict(id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

insert into public.profiles(id,display_name,role)
select id,coalesce(raw_user_meta_data->>'display_name',split_part(email,'@',1)),'customer_success' from auth.users
on conflict(id) do nothing;

create or replace function public.current_app_role() returns text language sql stable security definer set search_path=public as $$
  select role from public.profiles where id=auth.uid()
$$;

create or replace function public.fill_audit_user() returns trigger language plpgsql as $$
begin
  if tg_op='INSERT' then new.created_by=coalesce(new.created_by,auth.uid()); end if;
  new.updated_by=auth.uid(); return new;
end $$;
drop trigger if exists lost_items_audit_user on public.lost_items;
create trigger lost_items_audit_user before insert or update on public.lost_items for each row execute function public.fill_audit_user();
drop trigger if exists insurance_audit_user on public.insurance_claims;
create trigger insurance_audit_user before insert or update on public.insurance_claims for each row execute function public.fill_audit_user();

create or replace function public.generate_lost_management_no() returns trigger language plpgsql as $$
declare store_code text; date_key text; prefix text; next_no integer;
begin
  if new.management_no is not null then return new; end if;
  select coalesce(code,'STR') into store_code from public.master_records where id=new.store_id;
  date_key=to_char(new.found_at at time zone 'Asia/Tokyo','YYYYMMDD');
  prefix=store_code||'-'||date_key||'-';
  perform pg_advisory_xact_lock(hashtext(prefix));
  select coalesce(max(right(management_no,3)::integer),0)+1 into next_no from public.lost_items where management_no like prefix||'%';
  new.management_no=prefix||lpad(next_no::text,3,'0');
  return new;
end $$;
drop trigger if exists lost_items_management_no on public.lost_items;
create trigger lost_items_management_no before insert on public.lost_items for each row execute function public.generate_lost_management_no();

alter table public.profiles enable row level security;
alter table public.master_records enable row level security;
alter table public.app_settings enable row level security;
alter table public.lost_items enable row level security;
alter table public.insurance_claims enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (id=auth.uid() or public.current_app_role()='admin');
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated using (public.current_app_role()='admin') with check (public.current_app_role()='admin');

drop policy if exists masters_read on public.master_records;
create policy masters_read on public.master_records for select to authenticated using (true);
drop policy if exists masters_admin_insert on public.master_records;
create policy masters_admin_insert on public.master_records for insert to authenticated with check (public.current_app_role()='admin');
drop policy if exists masters_admin_update on public.master_records;
create policy masters_admin_update on public.master_records for update to authenticated using (public.current_app_role()='admin') with check (public.current_app_role()='admin');

drop policy if exists settings_read on public.app_settings;
create policy settings_read on public.app_settings for select to authenticated using (true);
drop policy if exists settings_admin_write on public.app_settings;
create policy settings_admin_write on public.app_settings for all to authenticated using (public.current_app_role()='admin') with check (public.current_app_role()='admin');

drop policy if exists lost_select on public.lost_items;
create policy lost_select on public.lost_items for select to authenticated using (public.current_app_role() in ('admin','lost_manager') or (public.current_app_role()='lost_register' and created_by=auth.uid()));
drop policy if exists lost_insert on public.lost_items;
create policy lost_insert on public.lost_items for insert to authenticated with check (public.current_app_role() in ('admin','lost_manager','lost_register'));
drop policy if exists lost_update on public.lost_items;
create policy lost_update on public.lost_items for update to authenticated using (public.current_app_role() in ('admin','lost_manager')) with check (public.current_app_role() in ('admin','lost_manager'));

drop policy if exists insurance_select on public.insurance_claims;
create policy insurance_select on public.insurance_claims for select to authenticated using (public.current_app_role() in ('admin','insurance_manager','customer_success'));
drop policy if exists insurance_insert on public.insurance_claims;
create policy insurance_insert on public.insurance_claims for insert to authenticated with check (public.current_app_role() in ('admin','insurance_manager'));
drop policy if exists insurance_update on public.insurance_claims;
create policy insurance_update on public.insurance_claims for update to authenticated using (public.current_app_role() in ('admin','insurance_manager')) with check (public.current_app_role() in ('admin','insurance_manager'));

insert into public.app_settings(key,value) values
('normal_retention_days','90'::jsonb),('valuable_retention_days','7'::jsonb),('image_max_px','1200'::jsonb),('image_quality','0.75'::jsonb),('photo_retention_days','180'::jsonb)
on conflict(key) do nothing;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('lost-item-images','lost-item-images',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false;

drop policy if exists lost_image_insert on storage.objects;
create policy lost_image_insert on storage.objects for insert to authenticated with check (bucket_id='lost-item-images' and public.current_app_role() in ('admin','lost_manager','lost_register'));
drop policy if exists lost_image_select on storage.objects;
create policy lost_image_select on storage.objects for select to authenticated using (bucket_id='lost-item-images' and public.current_app_role() in ('admin','lost_manager'));
drop policy if exists lost_image_update on storage.objects;
create policy lost_image_update on storage.objects for update to authenticated using (bucket_id='lost-item-images' and public.current_app_role() in ('admin','lost_manager'));
drop policy if exists lost_image_delete on storage.objects;
create policy lost_image_delete on storage.objects for delete to authenticated using (bucket_id='lost-item-images' and public.current_app_role() in ('admin','lost_manager'));
