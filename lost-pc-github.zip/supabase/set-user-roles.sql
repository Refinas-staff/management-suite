-- Auth > Users でユーザーを作成した後、メールアドレスに応じて役割を設定します。
-- 例のメールアドレスは実際のものへ変更してください。

update public.profiles set display_name='本部管理者', role='admin'
where id=(select id from auth.users where email='admin@example.com');

update public.profiles set display_name='忘れ物PC担当', role='lost_manager'
where id=(select id from auth.users where email='lost-pc@example.com');

update public.profiles set display_name='店舗iPad', role='lost_register'
where id=(select id from auth.users where email='lost-ipad@example.com');

update public.profiles set display_name='保険担当', role='insurance_manager'
where id=(select id from auth.users where email='insurance@example.com');

update public.profiles set display_name='カスタマーサクセス', role='customer_success'
where id=(select id from auth.users where email='cs@example.com');
