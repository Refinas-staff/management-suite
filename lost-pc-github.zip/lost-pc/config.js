window.APP_CONFIG = {
  // Supabase接続前は true のままで画面を確認できます。
  DEMO_MODE: true,

  // Supabase接続時に入力し、DEMO_MODE を false に変更してください。
  SUPABASE_URL: '',
  SUPABASE_PUBLISHABLE_KEY: '',

  STORAGE_BUCKET: 'lost-item-images',
  TIMEZONE: 'Asia/Tokyo'
};
