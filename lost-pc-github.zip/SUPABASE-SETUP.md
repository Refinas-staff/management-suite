# Supabase設定手順

3画面は同じSupabaseプロジェクトを使用します。設定は一度だけです。

## 1. SQLを実行

Supabase Dashboardの **SQL Editor** で次の順に実行します。

1. `supabase/setup.sql`
2. `supabase/seed-master.sql`（店舗名・店舗コードを修正してから実行）

`setup.sql`で以下を作成します。

- `profiles`
- `master_records`
- `app_settings`
- `lost_items`
- `insurance_claims`
- 非公開Storageバケット `lost-item-images`
- RLSポリシー
- 忘れ物管理番号の自動発行

## 2. ログインユーザーを作成

Supabase Dashboardの **Authentication > Users** から、必要なユーザーを作成します。

推奨例：

- 本部管理者
- 忘れ物PC担当
- 店舗iPad専用アカウント
- 保険担当
- カスタマーサクセス

## 3. 権限を設定

`supabase/set-user-roles.sql`内のメールアドレスを、作成したユーザーのものへ変更して実行します。

- `admin`：全機能
- `lost_manager`：忘れ物PC閲覧・ステータス変更
- `lost_register`：iPad新規登録
- `insurance_manager`：保険の閲覧・登録・編集
- `customer_success`：保険の閲覧のみ

## 4. 接続情報を設定

Supabase Dashboardの **Project Settings > API** で以下を確認します。

- Project URL
- Publishable key

3フォルダそれぞれの `config.js`を変更します。

```js
window.APP_CONFIG = {
  DEMO_MODE: false,
  SUPABASE_URL: 'https://xxxxx.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'sb_publishable_xxxxx',
  STORAGE_BUCKET: 'lost-item-images',
  TIMEZONE: 'Asia/Tokyo'
};
```

`service_role`、Secret key、データベースパスワードは入力しないでください。

## 5. GitHub Pagesへ公開

リポジトリ直下に全ファイルをアップロードし、GitHub Pagesを有効にします。

- `/lost-pc/`
- `/lost-ipad/`
- `/insurance-progress/`

## 6. iPadのホーム画面へ追加

Safariで `/lost-ipad/` を開きます。

1. 共有ボタン
2. 「ホーム画面に追加」
3. 「追加」

ロゴを変更するときは次を同名で置き換えます。

- `lost-ipad/assets/apple-touch-icon.png`（180×180）
- `lost-ipad/icons/icon-192.png`（192×192）
- `lost-ipad/icons/icon-512.png`（512×512）
- `lost-ipad/assets/favicon.svg`
- `lost-ipad/assets/favicon.ico`
